# Lá VS Code Extension

VS Code syntax highlighting extension for the **Lá** programming language.

## Folder Structure

```
vscode-la-syntax/
├── syntaxes/
│   └── la.tmLanguage.json      # Syntax rules
├── language-configuration.json  # Language config
├── package.json                 # Extension manifest
├── README.md                     # English guide
├── INSTALL_VI.md                # Vietnamese installation guide
├── CHANGELOG.md                  # Version history
├── example.la                    # Example code
└── .vscodeignore                # Files to ignore
```

## Quick Start

1. **Clone or copy the extension folder**
2. **Place in VS Code extensions folder**: `~/.vscode/extensions/`
3. **Restart VS Code**
4. **Create a `.la` file** - syntax highlighting will activate automatically!

## Building & Publishing

```bash
# Install dependencies
npm install -g vsce

# Package extension
vsce package

# Login to marketplace (optional, for publishing)
vsce login <publisher-name>

# Publish to marketplace
vsce publish
```

## File Structure Explained

- **syntaxes/la.tmLanguage.json**: Defines all the syntax highlighting rules using TextMate grammar
- **language-configuration.json**: Configures brackets, comments, and auto-closing pairs
- **package.json**: Extension metadata and contribution configuration

## Customization

To add more keywords or modify colors:

1. Edit `syntaxes/la.tmLanguage.json`
2. Add new patterns in the `repository` section
3. Restart VS Code to see changes

Example pattern to add:
```json
{
  "name": "keyword.custom.la",
  "match": "\\b(your_keyword)\\b"
}
```

## Theme Support

This extension works with all VS Code themes. Color appearance depends on your chosen theme settings.

## Publishing to Marketplace

1. Create a publisher account on VS Code Marketplace
2. Update version in `package.json`
3. Run `vsce package` to create `.vsix` file
4. Run `vsce publish` to publish

---

**Author**: Your Name
**License**: MIT
