@echo off
REM Lá Language VS Code Extension Installer (Windows)
REM This script installs the Lá language syntax highlighting extension for VS Code

setlocal enabledelayedexpansion

echo ========================================
echo Lá Language VS Code Extension Installer
echo ========================================
echo.

REM Get the directory where this script is located
set "SCRIPT_DIR=%~dp0"
set "EXTENSION_NAME=la-syntax"
set "SOURCE_DIR=%SCRIPT_DIR%"
set "EXTENSION_DIR=%APPDATA%\Code\User\extensions"

echo Detected OS: Windows
echo Extension directory: %EXTENSION_DIR%
echo Source directory: %SOURCE_DIR%
echo.

REM Check if extension source exists
if not exist "%SOURCE_DIR%\package.json" (
    echo Error: package.json not found in %SOURCE_DIR%
    echo Make sure you're running this script from the extension directory
    pause
    exit /b 1
)

REM Create extensions directory if it doesn't exist
if not exist "%EXTENSION_DIR%" (
    echo Creating extensions directory...
    mkdir "%EXTENSION_DIR%"
)

REM Target directory for the extension
set "TARGET_DIR=%EXTENSION_DIR%\%EXTENSION_NAME%"

REM Check if already installed
if exist "%TARGET_DIR%" (
    echo Extension already installed at: %TARGET_DIR%
    set /p OVERWRITE="Do you want to overwrite it? (y/n): "
    if /i not "!OVERWRITE!"=="y" (
        echo Installation cancelled
        pause
        exit /b 0
    )
    rmdir /s /q "%TARGET_DIR%"
)

REM Copy extension
echo Installing extension...
xcopy "%SOURCE_DIR%*" "%TARGET_DIR%\" /E /I /Y >nul

if %ERRORLEVEL% equ 0 (
    echo.
    echo ✓ Extension installed successfully!
    echo.
    echo Installation details:
    echo   Location: %TARGET_DIR%
    echo   Extension ID: la-syntax
    echo.
    echo Next steps:
    echo 1. Restart VS Code completely (close all windows^)
    echo 2. Open a .la file to see syntax highlighting
    echo.
    echo Installation complete!
) else (
    echo Error: Installation failed
    exit /b 1
)

pause
