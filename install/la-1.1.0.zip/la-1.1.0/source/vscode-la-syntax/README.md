# Lá Language Syntax Highlighting

Syntax highlighting support for the **Lá** programming language in VS Code.

## Features

✨ **Complete syntax highlighting** for Lá language including:
- Keywords (nếu, lặp, tạo, kết, etc.)
- Comments (// syntax)
- Strings and escape sequences
- Numbers (integers and floats)
- Operators and logical keywords (và, hoặc, không)
- Constants (đúng, sai, không_có, mãi)
- Variable recognition

## Installation

### Option 1: Install from VS Code Extensions Marketplace
Search for "Lá Language Syntax Highlighting" in the VS Code Extensions marketplace.

### Option 2: Install Locally
1. Copy this folder to `~/.vscode/extensions/la-syntax-1.0.0`
2. Restart VS Code

### Option 3: Build and Install
```bash
# Install vsce (VS Code Extension CLI)
npm install -g vsce

# Package the extension
vsce package

# Install the .vsix file
# Use Extensions > Install from VSIX... in VS Code
```

## Usage

Once installed, any `.la` file will automatically get syntax highlighting.

### Example:
Create a file named `hello.la`:

```la
// Hello World in Lá
in "Xin chào, thế giới!"

đặt x = 42
in x

tạo greet
    in "Xin chào!"
kết

greet
```

## Supported Keywords

### Control Flow
- `nếu` - if
- `nếu_không` - else
- `lặp` - loop
- `dừng` - break
- `trả_về` - return

### Statements
- `in` - print
- `nhập` - input
- `đặt` - assign variable
- `thêm` - add to list
- `xóa` - delete from list
- `xóa_tất` - clear

### Functions
- `tạo` - create function
- `kết` - end block

### Operators
- `và` - and
- `hoặc` - or
- `không` - not

### Constants
- `đúng` - true
- `sai` - false
- `không_có` - null
- `mãi` - infinity

## Theme Compatibility

This extension works with all VS Code themes. Color highlighting will adapt to your current theme.

## Settings

The extension uses VS Code's default syntax coloring configuration. Customize colors in your theme settings.

## License

MIT

## Contributing

Contributions are welcome! Please submit issues and pull requests to the repository.

## Support

For issues or questions, please visit the project repository or contact the developer.
