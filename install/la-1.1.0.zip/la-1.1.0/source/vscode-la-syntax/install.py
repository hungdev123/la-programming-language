#!/usr/bin/env python3

"""
Lá Language VS Code Extension Installer
Works on Windows, macOS, and Linux
"""

import os
import sys
import platform
import shutil
from pathlib import Path

# Colors for console output
class Colors:
    RESET = '\033[0m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[36m'

def log(message, color='RESET'):
    print(f"{getattr(Colors, color)}{message}{Colors.RESET}")

def get_extension_dir():
    """Get VS Code extensions directory based on OS"""
    home_dir = Path.home()
    system = platform.system()
    
    if system == 'Darwin':  # macOS
        return home_dir / 'Library' / 'Application Support' / 'Code' / 'User' / 'extensions'
    elif system == 'Linux':
        return home_dir / '.vscode' / 'extensions'
    elif system == 'Windows':
        appdata = os.getenv('APPDATA') or str(home_dir)
        return Path(appdata) / 'Code' / 'User' / 'extensions'
    else:
        raise Exception(f"Unsupported OS: {system}")

def get_platform_name():
    """Get readable platform name"""
    system = platform.system()
    if system == 'Darwin':
        return 'macOS'
    elif system == 'Linux':
        return 'Linux'
    elif system == 'Windows':
        return 'Windows'
    return system

def copy_directory(src, dst, skip_dirs=None):
    """Recursively copy directory, skipping certain files/dirs"""
    if skip_dirs is None:
        skip_dirs = {'.git', 'node_modules', '__pycache__', '.pytest_cache'}
    
    src_path = Path(src)
    dst_path = Path(dst)
    
    if not dst_path.exists():
        dst_path.mkdir(parents=True, exist_ok=True)
    
    for item in src_path.iterdir():
        # Skip certain files and directories
        if item.name in skip_dirs or item.name.startswith('.'):
            continue
        
        src_item = src_path / item.name
        dst_item = dst_path / item.name
        
        if src_item.is_dir():
            copy_directory(src_item, dst_item, skip_dirs)
        else:
            shutil.copy2(src_item, dst_item)

def install_extension():
    """Install the extension"""
    log('========================================', 'BLUE')
    log('Lá Language VS Code Extension Installer', 'BLUE')
    log('========================================', 'BLUE')
    log('')
    
    platform_name = get_platform_name()
    log(f'Detected OS: {platform_name}', 'YELLOW')
    
    try:
        extension_dir = get_extension_dir()
        log(f'Extension directory: {extension_dir}')
    except Exception as e:
        log(f'Error: {e}', 'RED')
        sys.exit(1)
    
    # Get script directory
    script_dir = Path(__file__).parent.absolute()
    source_dir = script_dir
    log(f'Source directory: {source_dir}')
    log('')
    
    # Check if package.json exists
    package_json = source_dir / 'package.json'
    if not package_json.exists():
        log('Error: package.json not found', 'RED')
        log('Make sure you are running this script from the extension directory', 'RED')
        sys.exit(1)
    
    # Create extensions directory if needed
    extension_dir.mkdir(parents=True, exist_ok=True)
    
    target_dir = extension_dir / 'la-syntax'
    
    # Check if already installed
    if target_dir.exists():
        log(f'Extension already installed at: {target_dir}', 'YELLOW')
        log('')
        log('Note: To update, delete the extension from VS Code Extensions panel', 'YELLOW')
        log(f'or manually remove: {target_dir}', 'YELLOW')
        sys.exit(0)
    
    # Copy extension
    log('Installing extension...', 'YELLOW')
    
    try:
        copy_directory(source_dir, target_dir)
        log('✓ Extension installed successfully!', 'GREEN')
        log('')
        log('Installation details:', 'BLUE')
        log(f'  Location: {target_dir}')
        log('  Extension ID: la-syntax')
        log('')
        log('Next steps:', 'YELLOW')
        log('1. Restart VS Code completely (close all windows)')
        log('2. Open a .la file to see syntax highlighting')
        log('')
        log('Installation complete!', 'GREEN')
    except Exception as e:
        log(f'Error: {e}', 'RED')
        sys.exit(1)

if __name__ == '__main__':
    install_extension()
