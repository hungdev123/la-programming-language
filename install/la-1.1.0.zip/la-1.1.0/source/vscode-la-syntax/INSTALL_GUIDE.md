# Lá Language VS Code Extension - Installation Guide

> **Lá Language Syntax Highlighting for VS Code**

This guide covers all installation methods for the Lá Language VS Code extension.

## Quick Installation (Recommended)

### Option 1: Automatic Installation Script

#### **Linux / macOS**
```bash
# Make script executable
chmod +x install.sh

# Run installer
./install.sh
```

#### **Windows**
```cmd
# Run the batch script
install.bat
```

#### **Any OS (Python)**
```bash
# Make script executable (Linux/macOS)
chmod +x install.py

# Run installer
python3 install.py
```

#### **Any OS (Node.js)**
```bash
# Make script executable (Linux/macOS)
chmod +x install.js

# Run installer
node install.js
```

---

## Manual Installation Methods

### Option 2: Copy to Extensions Folder

Find your VS Code extensions folder:

**Linux:**
```bash
cp -r . ~/.vscode/extensions/la-syntax
```

**macOS:**
```bash
cp -r . ~/Library/Application\ Support/Code/User/extensions/la-syntax
```

**Windows (PowerShell):**
```powershell
Copy-Item -Path . -Destination "$env:APPDATA\Code\User\extensions\la-syntax" -Recurse
```

Then restart VS Code.

---

### Option 3: Use vsce to Package & Install

**Prerequisites:** Node.js and npm installed

```bash
# Install vsce globally
npm install -g vsce

# Build package
./build.sh

# Or build manually
vsce package

# Install from VSIX file
code --install-extension la-syntax-1.0.0.vsix
```

---

### Option 4: Install from VSIX in VS Code UI

1. Open VS Code
2. Press `Ctrl+Shift+X` (or `Cmd+Shift+X` on macOS)
3. Click the three dots `⋯` menu
4. Select "Install from VSIX..."
5. Choose the `.vsix` file from this directory
6. Restart VS Code

---

## Verification

After installation:

1. Create a file named `test.la`
2. Paste this code:
   ```la
   // Test Lá syntax highlighting
   in "Hello, Lá!"
   đặt x = 42
   in x
   
   tạo greet
       in "Xin chào!"
   kết
   
   greet
   ```
3. You should see syntax highlighting applied to keywords, strings, and numbers

---

## Troubleshooting

### Extension not appearing after installation

**Solution:**
1. Make sure file has `.la` extension
2. Close and reopen the file
3. Restart VS Code completely (close all windows)
4. Check if extension is listed in `Extensions` panel

### Syntax highlighting not working

**Solution:**
1. Verify file extension is `.la`
2. Check `Extensions` panel - search for "Lá Language"
3. Ensure extension shows "Enabled"
4. Try reloading window: `Ctrl+K Ctrl+R` (or `Cmd+K Cmd+R` on macOS)

### Installation script errors

**For Linux/macOS:**
```bash
# Make sure script is executable
chmod +x install.sh
chmod +x build.sh
```

**For Node.js errors:**
```bash
# Ensure Node.js is installed
node --version
npm --version

# If not, run with Python instead
python3 install.py
```

---

## Uninstallation

### Option 1: VS Code UI
1. Open Extensions panel (`Ctrl+Shift+X`)
2. Search for "Lá Language"
3. Click "Uninstall"
4. Restart VS Code

### Option 2: Manual
Delete the extension folder:

**Linux:**
```bash
rm -rf ~/.vscode/extensions/la-syntax
```

**macOS:**
```bash
rm -rf ~/Library/Application\ Support/Code/User/extensions/la-syntax
```

**Windows:**
```powershell
Remove-Item -Path "$env:APPDATA\Code\User\extensions\la-syntax" -Recurse
```

---

## Advanced Options

### Development Installation

For extension development:

1. Clone the repository
2. Install dependencies: `npm install`
3. Open folder in VS Code
4. Press `F5` to start debugging
5. A new VS Code window will open with the extension enabled

### Publishing to Marketplace

```bash
# Create publisher account at https://marketplace.visualstudio.com

# Login
vsce login <publisher-name>

# Publish
vsce publish patch  # or minor, major for version bumps
```

---

## File Locations by OS

| OS | Location |
|----| ---------|
| **Linux** | `~/.vscode/extensions/` |
| **macOS** | `~/Library/Application Support/Code/User/extensions/` |
| **Windows** | `%APPDATA%\Code\User\extensions\` |

---

## Support

If you encounter issues:

1. Check the troubleshooting section above
2. Review the example code in `example.la`
3. Visit the project repository for more information

---

## What Gets Highlighted

✨ **Keywords:**
- Control flow: `nếu`, `nếu_không`, `lặp`, `dừng`, `trả_về`
- Statements: `in`, `nhập`, `đặt`, `thêm`, `xóa`, `xóa_tất`
- Functions: `tạo`, `kết`

✨ **Other:**
- Comments: `// ...`
- Strings: `"..."`
- Numbers: integers and floats
- Operators: `+`, `-`, `*`, `/`, `=`, `==`, `!=`, etc.
- Logical operators: `và`, `hoặc`, `không`
- Constants: `đúng`, `sai`, `không_có`, `mãi`

---

**Happy coding with Lá! 🍃**
