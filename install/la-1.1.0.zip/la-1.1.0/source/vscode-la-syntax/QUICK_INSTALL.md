# Installation Quick Reference

## 🚀 Fastest Way to Install

### Linux / macOS
```bash
./install.sh
```

### Windows
```cmd
install.bat
```

### Any OS (Python)
```bash
python3 install.py
```

### Any OS (Node.js)
```bash
node install.js
```

---

## 📦 Build & Package

### Create .vsix Package

#### Linux / macOS
```bash
./build.sh
```

#### Windows
```cmd
build.bat
```

---

## 📍 Installation Locations

After installation, the extension will be at:

- **Linux:** `~/.vscode/extensions/la-syntax`
- **macOS:** `~/Library/Application Support/Code/User/extensions/la-syntax`
- **Windows:** `%APPDATA%\Code\User\extensions\la-syntax`

---

## ✅ Verify Installation

1. Create a file `test.la`:
   ```la
   in "Hello, Lá!"
   đặt x = 42
   ```

2. Open it in VS Code
3. You should see colored syntax highlighting!

---

## 📚 Full Guide

See `INSTALL_GUIDE.md` for complete documentation with all installation methods and troubleshooting.

---

## 🔧 What's Included

- ✨ **install.sh** - Quick install (Linux/macOS)
- ✨ **install.bat** - Quick install (Windows)
- ✨ **install.py** - Python installer (any OS)
- ✨ **install.js** - Node.js installer (any OS)
- ✨ **build.sh** - Build/package script (Linux/macOS)
- ✨ **build.bat** - Build/package script (Windows)
- 📖 **INSTALL_GUIDE.md** - Complete installation guide
- 📄 **syntaxes/la.tmLanguage.json** - Syntax rules
- 📄 **language-configuration.json** - Language config
- 📄 **example.la** - Example code

---

## 🎨 After Installation

1. **Restart VS Code** completely
2. **Create or open** a `.la` file
3. **Enjoy** syntax highlighting! 🍃
