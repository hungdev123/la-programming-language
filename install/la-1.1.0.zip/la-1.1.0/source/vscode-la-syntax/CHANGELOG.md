# Changelog

## [1.0.0] - 2024

### Added
- Initial release of Lá Language Syntax Highlighting
- Support for `.la` file extension
- Syntax highlighting for all major keywords:
  - Control flow: `nếu`, `nếu_không`, `lặp`, `dừng`, `trả_về`
  - Statements: `in`, `nhập`, `đặt`, `thêm`, `xóa`, `xóa_tất`
  - Functions: `tạo`, `kết`
  - Logical operators: `và`, `hoặc`, `không`
  - Constants: `đúng`, `sai`, `không_có`, `mãi`
- Comment support (`//`)
- String highlighting with escape sequences
- Number highlighting (integers and floats)
- Variable recognition
- Operator highlighting
- Bracket matching and auto-closing
- Language configuration for VS Code integration

### Features
- Full syntax highlighting
- Comment line support
- String and escape sequence recognition
- Numeric literal support
- Theme compatibility with all VS Code themes
- Bracket matching
- Auto-close pairs

---

For bug reports and feature requests, please visit the repository.
