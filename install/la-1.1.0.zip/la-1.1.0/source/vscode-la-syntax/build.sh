#!/bin/bash

# Lá Language VS Code Extension - Build & Package Script
# This script packages the extension into a .vsix file for distribution

set -e

echo "========================================"
echo "Lá Language VS Code Extension Builder"
echo "========================================"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$SCRIPT_DIR"

echo "Project directory: $PROJECT_DIR"
echo ""

# Check if package.json exists
if [ ! -f "$PROJECT_DIR/package.json" ]; then
    echo -e "${RED}Error: package.json not found${NC}"
    exit 1
fi

# Check if vsce is installed
if ! command -v vsce &> /dev/null; then
    echo -e "${YELLOW}vsce not found. Installing...${NC}"
    npm install -g vsce
fi

# Get version from package.json
VERSION=$(grep -o '"version": "[^"]*"' "$PROJECT_DIR/package.json" | cut -d'"' -f4)
echo -e "${YELLOW}Building Lá Language Extension v$VERSION${NC}"
echo ""

# Create dist directory if it doesn't exist
mkdir -p "$PROJECT_DIR/dist"

echo -e "${YELLOW}Packaging extension...${NC}"

# Package the extension
cd "$PROJECT_DIR"
vsce package -o "dist/la-syntax-$VERSION.vsix"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Package created successfully!${NC}"
    echo ""
    echo "Output: dist/la-syntax-$VERSION.vsix"
    echo ""
    echo -e "${YELLOW}Installation methods:${NC}"
    echo "1. In VS Code: Ctrl+Shift+X > ... > Install from VSIX"
    echo "2. Command line: code --install-extension dist/la-syntax-$VERSION.vsix"
    echo "3. Shell script: ./install.sh"
    echo ""
    
    # Ask if user wants to install
    read -p "Do you want to install the extension now? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo ""
        echo -e "${YELLOW}Installing extension...${NC}"
        code --install-extension "dist/la-syntax-$VERSION.vsix"
        echo -e "${GREEN}Extension installed!${NC}"
        echo "Restart VS Code to see changes"
    fi
else
    echo -e "${RED}Error: Package creation failed${NC}"
    exit 1
fi
