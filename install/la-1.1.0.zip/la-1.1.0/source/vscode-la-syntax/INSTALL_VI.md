# Hướng dẫn cài đặt VS Code Extension cho Lá

## Cách 1: Cài đặt từ Marketplace (Sắp tới)

Tìm kiếm "Lá Language" hoặc "la-syntax" trong Extensions của VS Code.

## Cách 2: Cài đặt từ tệp .vsix

1. **Tạo tệp extension**:
   ```bash
   npm install -g vsce
   cd vscode-la-syntax
   vsce package
   ```

2. **Cài đặt extension**:
   - Mở VS Code
   - Bấm `Ctrl+Shift+X` (Extensions)
   - Bấm vào ba chấm `...` > "Install from VSIX..."
   - Chọn file `la-syntax-1.0.0.vsix`

## Cách 3: Cài đặt thủ công (Development Mode)

1. **Copy toàn bộ thư mục** `vscode-la-syntax` vào:
   ```
   ~/.vscode/extensions/
   ```

2. **Khởi động lại VS Code**

## Cách 4: Clone từ Git (Developer Mode)

```bash
git clone <repository-url> ~/.vscode/extensions/vscode-la-syntax
```

## Kiểm tra cài đặt

1. Tạo một tệp với phần mở rộng `.la`
2. Mở nó trong VS Code
3. Bạn sẽ thấy syntax highlighting được bật lên

## Gỡ cài đặt

- Mở Extensions trong VS Code (`Ctrl+Shift+X`)
- Tìm "Lá Language Syntax Highlighting"
- Bấm "Uninstall"

## Xử sự cố

**Syntax highlighting không hoạt động?**
- Kiểm tra file có phần mở rộng `.la`
- Khởi động lại VS Code
- Xóa `.vscode/extensions` cache và cài lại

**Muốn thay đổi màu sắc?**
- Đây phụ thuộc vào theme bạn sử dụng
- Thay đổi theme từ Settings > Color Theme

## Hỗ trợ

Nếu gặp vấn đề, vui lòng báo cáo tại GitHub repository.
