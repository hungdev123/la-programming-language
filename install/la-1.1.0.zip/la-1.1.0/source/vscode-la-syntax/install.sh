#!/bin/bash

# Lá Language VS Code Extension Installer
# This script installs the Lá language syntax highlighting extension for VS Code

set -e

echo "========================================"
echo "Lá Language VS Code Extension Installer"
echo "========================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Determine OS
OS_TYPE=$(uname -s)
EXTENSION_DIR=""

case "$OS_TYPE" in
    Darwin)
        EXTENSION_DIR="$HOME/Library/Application Support/Code/User/extensions"
        OS_NAME="macOS"
        ;;
    Linux)
        EXTENSION_DIR="$HOME/.vscode/extensions"
        OS_NAME="Linux"
        ;;
    MINGW* | MSYS* | CYGWIN*)
        EXTENSION_DIR="$USERPROFILE/AppData/Roaming/Code/User/extensions"
        OS_NAME="Windows"
        ;;
    *)
        echo -e "${RED}Unsupported OS: $OS_TYPE${NC}"
        exit 1
        ;;
esac

echo -e "${YELLOW}Detected OS: $OS_NAME${NC}"
echo "Extension directory: $EXTENSION_DIR"
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
EXTENSION_NAME="la-syntax"
SOURCE_DIR="$SCRIPT_DIR"

echo "Source directory: $SOURCE_DIR"
echo ""

# Check if extension source exists
if [ ! -f "$SOURCE_DIR/package.json" ]; then
    echo -e "${RED}Error: package.json not found in $SOURCE_DIR${NC}"
    echo "Make sure you're running this script from the extension directory"
    exit 1
fi

# Create extensions directory if it doesn't exist
if [ ! -d "$EXTENSION_DIR" ]; then
    echo -e "${YELLOW}Creating extensions directory...${NC}"
    mkdir -p "$EXTENSION_DIR"
fi

# Target directory for the extension
TARGET_DIR="$EXTENSION_DIR/$EXTENSION_NAME"

# Check if already installed
if [ -d "$TARGET_DIR" ]; then
    echo -e "${YELLOW}Extension already installed at: $TARGET_DIR${NC}"
    read -p "Do you want to overwrite it? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled"
        exit 0
    fi
    rm -rf "$TARGET_DIR"
fi

# Copy extension
echo -e "${YELLOW}Installing extension...${NC}"
cp -r "$SOURCE_DIR" "$TARGET_DIR"

echo -e "${GREEN}✓ Extension installed successfully!${NC}"
echo ""
echo "Installation details:"
echo "  Location: $TARGET_DIR"
echo "  Extension ID: la-syntax"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "1. Restart VS Code completely (close all windows)"
echo "2. Open a .la file to see syntax highlighting"
echo ""
echo -e "${GREEN}Installation complete!${NC}"
