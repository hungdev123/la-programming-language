@echo off
REM Lá Language VS Code Extension - Build & Package Script (Windows)
REM This script packages the extension into a .vsix file for distribution

setlocal enabledelayedexpansion

echo ========================================
echo Lá Language VS Code Extension Builder
echo ========================================
echo.

set "SCRIPT_DIR=%~dp0"
set "PROJECT_DIR=%SCRIPT_DIR%"

echo Project directory: %PROJECT_DIR%
echo.

REM Check if package.json exists
if not exist "%PROJECT_DIR%\package.json" (
    echo Error: package.json not found
    pause
    exit /b 1
)

REM Check if vsce is installed
where vsce >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo vsce not found. Installing...
    call npm install -g vsce
)

REM Get version from package.json (simple approach)
for /f "tokens=2 delims=:" %%i in ('findstr "version" "%PROJECT_DIR%\package.json" ^| findstr /v "//"') do (
    set "VERSION=%%i"
    set "VERSION=!VERSION:"=!"
    set "VERSION=!VERSION: =!"
    set "VERSION=!VERSION:,=!"
    goto :found_version
)

:found_version
echo Building Lá Language Extension v%VERSION%
echo.

REM Create dist directory
if not exist "%PROJECT_DIR%\dist" mkdir "%PROJECT_DIR%\dist"

echo Packaging extension...
cd /d "%PROJECT_DIR%"

REM Package the extension
call vsce package -o "dist/la-syntax-%VERSION%.vsix"

if %ERRORLEVEL% equ 0 (
    echo.
    echo ✓ Package created successfully!
    echo.
    echo Output: dist/la-syntax-%VERSION%.vsix
    echo.
    echo Installation methods:
    echo 1. In VS Code: Ctrl+Shift+X ^> ... ^> Install from VSIX
    echo 2. Command line: code --install-extension dist/la-syntax-%VERSION%.vsix
    echo 3. Script: install.bat
    echo.
    
    set /p INSTALL="Do you want to install the extension now? (y/n): "
    if /i "!INSTALL!"=="y" (
        echo.
        echo Installing extension...
        call code --install-extension "dist/la-syntax-%VERSION%.vsix"
        echo Extension installed!
        echo Restart VS Code to see changes
    )
) else (
    echo Error: Package creation failed
    pause
    exit /b 1
)

pause
