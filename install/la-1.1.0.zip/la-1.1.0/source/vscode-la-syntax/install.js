#!/usr/bin/env node

/**
 * Lá Language VS Code Extension Installer
 * Works on Windows, macOS, and Linux
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[36m',
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function getExtensionDir() {
  const platform = process.platform;
  const homeDir = os.homedir();

  switch (platform) {
    case 'darwin':
      return path.join(homeDir, 'Library', 'Application Support', 'Code', 'User', 'extensions');
    case 'linux':
      return path.join(homeDir, '.vscode', 'extensions');
    case 'win32':
      return path.join(process.env.APPDATA || homeDir, 'Code', 'User', 'extensions');
    default:
      throw new Error(`Unsupported OS: ${platform}`);
  }
}

function getPlatformName() {
  const platform = process.platform;
  switch (platform) {
    case 'darwin':
      return 'macOS';
    case 'linux':
      return 'Linux';
    case 'win32':
      return 'Windows';
    default:
      return platform;
  }
}

async function installExtension() {
  log('========================================', 'blue');
  log('Lá Language VS Code Extension Installer', 'blue');
  log('========================================', 'blue');
  log('');

  const platformName = getPlatformName();
  log(`Detected OS: ${platformName}`, 'yellow');

  const extensionDir = getExtensionDir();
  log(`Extension directory: ${extensionDir}`);

  const scriptDir = __dirname;
  const sourceDir = scriptDir;
  log(`Source directory: ${sourceDir}`);
  log('');

  // Check if package.json exists
  const packageJsonPath = path.join(sourceDir, 'package.json');
  if (!fs.existsSync(packageJsonPath)) {
    log('Error: package.json not found', 'red');
    log('Make sure you are running this script from the extension directory', 'red');
    process.exit(1);
  }

  // Create extensions directory if it doesn't exist
  if (!fs.existsSync(extensionDir)) {
    log('Creating extensions directory...', 'yellow');
    fs.mkdirSync(extensionDir, { recursive: true });
  }

  const targetDir = path.join(extensionDir, 'la-syntax');

  // Check if already installed
  if (fs.existsSync(targetDir)) {
    log(`Extension already installed at: ${targetDir}`, 'yellow');
    log('');
    log('Note: To update, delete the extension from VS Code Extensions panel', 'yellow');
    log('or manually remove: ' + targetDir, 'yellow');
    process.exit(0);
  }

  // Copy extension
  log('Installing extension...', 'yellow');

  try {
    copyDirectory(sourceDir, targetDir);
    log('✓ Extension installed successfully!', 'green');
    log('');
    log('Installation details:', 'blue');
    log(`  Location: ${targetDir}`);
    log('  Extension ID: la-syntax');
    log('');
    log('Next steps:', 'yellow');
    log('1. Restart VS Code completely (close all windows)');
    log('2. Open a .la file to see syntax highlighting');
    log('');
    log('Installation complete!', 'green');
  } catch (error) {
    log(`Error: ${error.message}`, 'red');
    process.exit(1);
  }
}

function copyDirectory(src, dst) {
  // Create destination if it doesn't exist
  if (!fs.existsSync(dst)) {
    fs.mkdirSync(dst, { recursive: true });
  }

  // List all files and directories in source
  const files = fs.readdirSync(src);

  for (const file of files) {
    // Skip certain files/directories
    if (['.git', 'node_modules', '.gitignore', '.vscodeignore'].includes(file)) {
      continue;
    }

    const srcPath = path.join(src, file);
    const dstPath = path.join(dst, file);
    const stat = fs.statSync(srcPath);

    if (stat.isDirectory()) {
      copyDirectory(srcPath, dstPath);
    } else {
      fs.copyFileSync(srcPath, dstPath);
    }
  }
}

// Run installation
installExtension().catch((error) => {
  log(`Unexpected error: ${error.message}`, 'red');
  process.exit(1);
});
