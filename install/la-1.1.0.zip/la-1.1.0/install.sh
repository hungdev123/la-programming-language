#!/bin/bash
# Installer

echo "Welcome to the Linux installation script!"
echo "Make sure you have the necessary permissions to run this script."

echo "This script will install the La programming language."
read -p "Press [Enter] to continue or [Ctrl+C] to cancel." choose

echo "Deleting old files..."
sudo rm -f /usr/local/bin/la1
sudo rm -f /usr/local/bin/la-ide

echo "Copying files to /usr/local/bin..."
if [ -f source/la1 ]; then
  sudo cp source/la1 /usr/local/bin/la1
else
  echo "Warning: source/la1 not found. Skipping la1 installation."
fi

echo "Setting permissions..."
if [ -f /usr/local/bin/la1 ]; then
  sudo chmod +x /usr/local/bin/la1
fi

echo "Would you like to install the VS Code extension for La syntax highlighting? (y/n)"
read -r install_extension
if [[ "$install_extension" =~ ^[Yy]$ ]]; then
  echo "Installing VS Code extension..."
  cp -r source/vscode-la-syntax ~/.vscode/extensions/
else
  echo "Skipping VS Code extension installation."
fi


echo "Installation complete!"
echo "Use 'la1' to run the La interpreter."