#!/bin/bash
# Installer

echo "Welcome to the Linux installation script!"
echo "Make sure you have the necessary permissions to run this script."

echo "This script will install La programming language."
read -p "Press [Enter] to continue or [Ctrl+C] to cancel." choose

echo "Deleting old files..."
sudo rm -rf /usr/local/bin/la1

echo "Copying files to /usr/local/bin..."
sudo cp source/la1 /usr/local/bin

echo "Setting permissions..."
sudo chmod +x /usr/local/bin/la1

echo "Installation complete! Use 'la1' command to run the La programming language."